'use strict';
'use ui';

var view = L.view;

return view.extend({
	load: function() {
		L.uci.unload('openvpn');
		return Promise.all([
			L.uci.load('openvpn'),
			L.resolveDefault(L.fs.read('/var/run/openvpn.my.pid'), ''),
			// Fetch system logs filtered by the native -e openvpn parameter
			L.resolveDefault(L.fs.exec('logread', ['-e', 'openvpn']), ''),
			// Read the active config file to reliably determine the configured port
			L.resolveDefault(L.fs.read('/etc/openvpn/my.conf'), '')
		]);
	},

	render: function(results) {
		var isRunning = false;
		var activePid = (results && results.length > 1 && results[1]) ? String(results[1]).trim() : '';

		if (activePid !== '' && !isNaN(activePid)) {
			isRunning = true;
		}

		// Crisis-proof port extraction from my.conf (Index 3)
		var activePort = '1194'; // Default OpenVPN port fallback
		if (results && results.length > 3 && results[3]) {
			var configContent = String(results[3]);
			var portMatch = configContent.match(/^port\s+(\d+)/m);
			if (portMatch && portMatch[1]) {
				activePort = portMatch[1];
			}
		}

		var rawVal = L.uci.get('openvpn', 'my', 'enabled');
		var dbEnabled = (rawVal === '1' || rawVal === 1 || rawVal === true || rawVal === 'on') ? 1 : 0;

		var statusEl;
		if (isRunning) {
			// OPTIMIZED: Increased font size to 140% for strong visual presence
			statusEl = E('span', { 'style': 'color:green; font-weight:bold; font-size:140%;' }, '● Running (PID: ' + activePid + ', Port: ' + activePort + ')');
		} else {
			statusEl = E('span', { 'style': 'color:red; font-weight:bold; font-size:140%;' }, '● Stopped (Config Port: ' + activePort + ')');
		}

		var statusCard = E('div', { 'class': 'cbi-map' }, [
			E('h3', {}, 'Daemon Status'),
			E('div', { 'class': 'cbi-section' }, [
				E('div', { 'class': 'cbi-map-descr' }, 'Here you can view the active state of your VPN connection.'),
				E('div', { 'class': 'cbi-value' }, [
					E('label', { 'class': 'cbi-value-title', 'style': 'font-size:120%; font-weight:bold;' }, 'Current State:'),
					E('div', { 'class': 'cbi-value-field' }, statusEl)
				])
			])
		]);

		// Process raw logread -e openvpn stdout lines
		var vpnLogLines = '';
		if (results && results.length > 2 && results[2]) {
			vpnLogLines = results[2].stdout || results[2];
		}
		
		if (!vpnLogLines || !String(vpnLogLines).trim()) {
			vpnLogLines = 'No active OpenVPN log entries found in system log.';
		}

		var logCard = E('div', { 'class': 'cbi-map', 'style': 'margin-top: 20px;' }, [
			E('h3', {}, 'VPN Log / Error Output (logread -e openvpn)'),
			E('div', { 'class': 'cbi-section' }, [
				E('div', { 'class': 'cbi-map-descr' }, 'Filtered real-time execution events from the routing engine:'),
				E('div', { 'class': 'cbi-value' }, [
					E('textarea', {
						'style': 'width: 100%; font-family: monospace; font-size: 12px; background: #222; color: #fff; padding: 10px; border-radius: 4px;',
						'rows': '10',
						'readonly': 'readonly',
						'wrap': 'off'
					}, String(vpnLogLines).trim())
				])
			])
		]);

		return L.require('form').then(function(form) {
			var m, s;

			m = new form.Map('openvpn', 'OpenVPN', 'Here you can manage and edit your OpenVPN instance.');

			s = m.section(form.TypedSection, 'openvpn', 'Instance Settings');
			s.anonymous = true;

			// 1. Link the checkbox directly to the UCI 'enabled' configuration key
			var enabledOption = s.option(form.Flag, 'enabled', 'Enabled');
			enabledOption.rmempty = false;
			enabledOption.cfgvalue = function(section_id) {
				return L.uci.get('openvpn', section_id, 'enabled') === '1' ? '1' : '0';
			};

			// Helper function to build native HTML5 file upload inputs
			var createUploadRow = function(label, filename) {
				var fileInput = E('input', { 'type': 'file', 'style': 'margin-top: 5px;' });
				var statusMsg = E('span', { 'style': 'margin-left: 10px; font-weight: bold;' }, '');
				
				fileInput.addEventListener('change', function(ev) {
					var file = ev.target.files[0];
					if (!file) return;
					
					statusMsg.textContent = '⏳ Uploading...';
					statusMsg.style.color = 'orange';

					var reader = new FileReader();
					reader.onload = function(e) {
						L.fs.write('/etc/openvpn/server/' + filename, e.target.result)
							.then(function() {
								statusMsg.textContent = '✅ Success';
								statusMsg.style.color = 'green';
							})
							.catch(function(err) {
								statusMsg.textContent = '❌ Error: ' + err.message;
								statusMsg.style.color = 'red';
							});
					};
					reader.readAsText(file);
				});

				return E('div', { 'class': 'cbi-value' }, [
					E('label', { 'class': 'cbi-value-title' }, label),
					E('div', { 'class': 'cbi-value-field' }, [fileInput, statusMsg])
				]);
			};

			// --- Virtual DummyValue container for targeted crypto uploads ---
			var uploadContainer = s.option(form.DummyValue, '_uploads', 'Crypto Key Management');
			uploadContainer.rawhtml = true;
			uploadContainer.cfgvalue = function() {
				return E('div', { 'style': 'border: 1px solid #ccc; padding: 10px; border-radius: 4px; margin-bottom: 15px; background: rgba(0,0,0,0.02);' }, [
					E('div', { 'style': 'margin-bottom: 10px; font-style: italic; color: #555;' }, 'Select keys to upload them instantly to the designated system directory.'),
					createUploadRow('Upload to: /etc/openvpn/server/ca.crt', 'ca.crt'),
					createUploadRow('Upload to: /etc/openvpn/server/server.crt', 'server.crt'),
					createUploadRow('Upload to: /etc/openvpn/server/server.key', 'server.key'),
					createUploadRow('Upload to: /etc/openvpn/server/dh.pem', 'dh.pem'),
					createUploadRow('Upload to: /etc/openvpn/server/tls-crypt.key', 'tls-crypt.key')
				]);
			};

			// 2. Map configuration editor directly onto the local text profile
			var editorOption = s.option(form.TextValue, 'customeditor', 'Edit OpenVPN config file (/etc/openvpn/my.conf)');
			editorOption.rows = 15;
			editorOption.wrap = 'off';
			editorOption.rmempty = true;

			editorOption.cfgvalue = function() {
				var path = '/etc/openvpn/my.conf';
				return L.resolveDefault(L.fs.read(path), '')
					.then(function(content) {
						return content || '# Modern OpenVPN Server Configuration\ndev tun\nproto udp\nport 1194\n\nca /etc/openvpn/server/ca.crt\ncert /etc/openvpn/server/server.crt\nkey /etc/openvpn/server/server.key\ndh /etc/openvpn/server/dh.pem\n\ncipher AES-256-GCM\ndata-ciphers AES-256-GCM:AES-128-GCM\ntls-crypt /etc/openvpn/server/tls-crypt.key\n\nserver 10.8.0.0 255.255.255.0\nkeepalive 10 120\nverb 3';
					});
			};

			// Synchronize written raw text data into the global LuCI save pipeline execution flow
			editorOption.write = function(section_id, formvalue) {
				var path = '/etc/openvpn/my.conf';
				
				// Force setup synchronization path binding inside the local uci database
				L.uci.set('openvpn', section_id, 'config', path);

				if (!formvalue || formvalue.trim() === '' || formvalue.indexOf('# Paste') === 0) {
					return;
				}
				
				// Write data atomically onto the physical flash layout
				return L.fs.write(path, formvalue.trim() + '\n');
			};

			return m.render().then(function(mapEl) {
				return E('div', {}, [
					statusCard,
					mapEl,
					logCard
				]);
			});
		});
	}
});

