'use strict';
/* This tells LuCI to load the mandatory form and view libraries */
var form = L.require('ui.form');

return L.view.extend({
	handleSaveApply: null,
	handleSave: null,
	handleReset: null,
	render: function() {
		var m, s, o;
		m = new form.Map('openvpn', 'OpenVPN', _('Here you can manage your OpenVPN instances.'));
		s = m.section(form.GridSection, 'openvpn', _('OpenVPN Instances'));
		s.anonymous = true;
		s.addremove = true;
		
		o = s.option(form.Flag, 'enabled', _('Enabled'));
		o.rmempty = false;
		
		o = s.option(form.Value, 'config', _('Configuration File (.conf)'));
		o.placeholder = '/etc/openvpn/my_connection.conf';
		
		return m.render();
	}
});

