'use strict';
'use ui';

var view = L.view;
var ui = L.require('ui');

// Official unified UBUS interface mapping for services status
var getServiceStatus = L.rpc.declare({
	object: 'service',
	method: 'list',
	params: [ 'name' ]
});

return view.extend({
	handleSaveApply: null,
	handleSave: null,
	handleReset: null,

	load: function() {
		// Strictly load only what LuCI needs for the form and the UBUS packet parallelized
		return Promise.all([
			L.uci.load('openvpn'),
			getServiceStatus({ name: 'openvpn' })
		]);
	},

	render: function(results) {
		// 1. Safely extract the UBUS result from the second slot of the array
		var ubusResult = (results && results.length > 1) ? results[1] : null;
		var openvpnData = (ubusResult && ubusResult.openvpn) ? ubusResult.openvpn : null;
		
		var isRunning = false;
		var pids = [];

		if (openvpnData && openvpnData.instances) {
			for (var inst in openvpnData.instances) {
				if (openvpnData.instances[inst].running === true) {
					isRunning = true;
					if (openvpnData.instances[inst].pid) {
						pids.push(openvpnData.instances[inst].pid);
					}
				}
			}
		}

		// 2. Generate a standalone, pure HTML Node for the Status Display (Bypasses CBI completely)
		var statusEl;
		if (isRunning) {
			statusEl = E('span', { 'style': 'color:green; font-weight:bold;' }, '● Running (PID: ' + pids.join(', ') + ')');
		} else {
			statusEl = E('span', { 'style': 'color:red; font-weight:bold;' }, '● Stopped');
		}

		var statusCard = E('div', { 'class': 'cbi-map' }, [
			E('h3', {}, 'Daemon Status'),
			E('div', { 'class': 'cbi-section' }, [
				E('div', { 'class': 'cbi-value' }, [
					E('label', { 'class': 'cbi-value-title' }, 'Current State'),
					E('div', { 'class': 'cbi-value-field' }, statusEl)
				])
			])
		]);

		// 3. Build the standard configuration map linked to /etc/config/openvpn
		return L.require('form').then(function(form) {
			var m, s, o;

			m = new form.Map('openvpn', 'OpenVPN', 'Here you can manage and edit your OpenVPN instances.');

			// SECTION 2: Clean UCI Table for Instances
			s = m.section(form.TableSection, 'openvpn', 'openvpn');
			s.anonymous = false;
			s.addremove = true;

			o = s.option(form.Flag, 'enabled', 'Enabled');
			o.rmempty = false;

			o = s.option(form.Value, 'config', 'Configuration File (.conf)');
			o.placeholder = '/etc/openvpn/my.conf';
			o.rmempty = false;

			// SECTION 3: Completely independent editor area below the table
			s = m.section(form.TypedSection, 'openvpn', 'Inline Configuration Editor');
			s.anonymous = true;
			
			var editorOption = s.option(form.TextValue, 'customeditor', 'Edit Active File');
			editorOption.rows = 15;
			editorOption.wrap = 'off';
			editorOption.rmempty = true;

			editorOption.cfgvalue = function(section_id) {
				var path = L.uci.get('openvpn', section_id, 'config') || '/etc/openvpn/my.conf';
				return L.resolveDefault(L.fs.read(path), '')
					.then(function(content) {
						return content || '# File does not exist yet. Paste your OVPN content here.';
					});
			};

			editorOption.write = function() {};

			// Execution Button
			o = s.option(form.Button, 'savebtn', 'Action');
			o.inputtitle = 'Update & Apply';
			o.inputstyle = 'apply';
			o.rmempty = true;
			
			o.onclick = function(ev, section_id) {
				var path = '/etc/openvpn/my.conf';
				var textContent = editorOption.formvalue(section_id);

				if (!textContent || textContent.trim() === '' || textContent.indexOf('# Enter') === 0) {
					alert('Error: Cannot write placeholder or empty text.');
					return;
				}

				L.require('ui').then(function(uiModule) {
					uiModule.showModal(null, [
						E('p', { 'class': 'spinning' }, 'Writing configuration and forcing absolute system daemon kick...')
					]);
				});

				var uciContent = "package openvpn\n\nconfig openvpn 'my'\n\toption enabled '1'\n\toption config '" + path + "'\n";

				return L.fs.write(path, textContent.trim() + '\n')
					.then(function() {
						return L.fs.write('/etc/config/openvpn', uciContent);
					})
					.then(function() {
						return L.resolveDefault(L.post('ubus', 'call', { 'object': 'uci', 'method': 'apply', 'params': { 'rollback': true } }), {});
					})
					.then(function() {
						return L.resolveDefault(L.post('ubus', 'call', {
							'object': 'rc',
							'method': 'run',
							'params': { 'name': 'openvpn', 'action': 'restart' }
						}), {});
					})
					.then(function() {
						setTimeout(function() { window.location.reload(); }, 1000);
					})
					.catch(function(err) {
						alert('Failed to apply update: ' + err.message);
					});
			};

			// We render the CBI map and append it right below our custom HTML status card
			return m.render().then(function(mapEl) {
				return E('div', {}, [
					statusCard,
					mapEl
				]);
			});
		});
	}
});


